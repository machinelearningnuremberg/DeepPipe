# DeepPipe

DeepPipe efficiently optimizes Machine Learning Pipelines using meta-learning.

## Install 

`
pip install deeppipe
`



